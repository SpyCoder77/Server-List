package net.mcreator.serverlist.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.client.gui.components.EditBox;

import net.mcreator.serverlist.world.inventory.Page4Menu;
import net.mcreator.serverlist.world.inventory.Page3Menu;
import net.mcreator.serverlist.world.inventory.Page2Menu;
import net.mcreator.serverlist.world.inventory.Page1Menu;
import net.mcreator.serverlist.ServerListMod;

import java.util.HashMap;

public class TickProcedure {
	public static void execute(LevelAccessor world, Entity entity, HashMap guistate) {
		if (entity == null || guistate == null)
			return;
		ServerListMod.queueServerWork(1, () -> {
			if (entity instanceof Player _plr ? _plr.containerMenu instanceof Page1Menu : false) {
				if (guistate.get("text:hypixel") instanceof EditBox _tf)
					_tf.setValue("mc.hypixel.net");
				if (guistate.get("text:cubecraft") instanceof EditBox _tf)
					_tf.setValue("play.cubecraft.net");
				if (guistate.get("text:mineplex") instanceof EditBox _tf)
					_tf.setValue("us.mineplex.com");
			} else {
				if (entity instanceof Player _plr ? _plr.containerMenu instanceof Page2Menu : false) {
					if (guistate.get("text:pvp_legacy") instanceof EditBox _tf)
						_tf.setValue("play.pvplegacy.net");
					if (guistate.get("text:minemen") instanceof EditBox _tf)
						_tf.setValue("mineman.club");
				} else {
					if (entity instanceof Player _plr ? _plr.containerMenu instanceof Page3Menu : false) {
						if (guistate.get("text:hypixel") instanceof EditBox _tf)
							_tf.setValue("mc.hypixel.net");
					} else {
						if (entity instanceof Player _plr ? _plr.containerMenu instanceof Page4Menu : false) {
							if (guistate.get("text:minehut") instanceof EditBox _tf)
								_tf.setValue("minehut.com");
						}
					}
				}
			}
		});
	}
}
