
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.serverlist.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.serverlist.world.inventory.Page4Menu;
import net.mcreator.serverlist.world.inventory.Page3Menu;
import net.mcreator.serverlist.world.inventory.Page2Menu;
import net.mcreator.serverlist.world.inventory.Page1Menu;
import net.mcreator.serverlist.ServerListMod;

public class ServerListModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, ServerListMod.MODID);
	public static final RegistryObject<MenuType<Page1Menu>> PAGE_1 = REGISTRY.register("page_1", () -> IForgeMenuType.create(Page1Menu::new));
	public static final RegistryObject<MenuType<Page2Menu>> PAGE_2 = REGISTRY.register("page_2", () -> IForgeMenuType.create(Page2Menu::new));
	public static final RegistryObject<MenuType<Page3Menu>> PAGE_3 = REGISTRY.register("page_3", () -> IForgeMenuType.create(Page3Menu::new));
	public static final RegistryObject<MenuType<Page4Menu>> PAGE_4 = REGISTRY.register("page_4", () -> IForgeMenuType.create(Page4Menu::new));
}
