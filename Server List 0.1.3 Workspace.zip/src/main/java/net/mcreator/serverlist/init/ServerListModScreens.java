
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.serverlist.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.serverlist.client.gui.Page4Screen;
import net.mcreator.serverlist.client.gui.Page3Screen;
import net.mcreator.serverlist.client.gui.Page2Screen;
import net.mcreator.serverlist.client.gui.Page1Screen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ServerListModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(ServerListModMenus.PAGE_1.get(), Page1Screen::new);
			MenuScreens.register(ServerListModMenus.PAGE_2.get(), Page2Screen::new);
			MenuScreens.register(ServerListModMenus.PAGE_3.get(), Page3Screen::new);
			MenuScreens.register(ServerListModMenus.PAGE_4.get(), Page4Screen::new);
		});
	}
}
